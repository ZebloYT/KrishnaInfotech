# Krishna Infotech — Client Handover Package
Official Website Production Build
Proprietor: Vikrant Madane
GSTIN: 27AOAPM2539L1ZR
Attribution: MADE BY trendustyorbit.online

## Included Pages & Assets:
- index.html: Homepage with full-bleed services, metrics, OEM infrastructure, digital reporting, and quote engine.
- products.html: Full hardware catalog (33 verified products, 5 pre-built gaming rigs, hot deals, 10-slot custom PC configurator, cart drawer, and WhatsApp quote dispatch).
- contact.html: About & Contact page with priority ticket helpdesk, remote KDesk support info, and registered office details.
- privacy-policy.html: Complete commercial privacy policy, data security practices, and statutory GST compliance.
- css/: Production stylesheets with full-bleed responsive layout and dark/light mode theme system.
- js/: High-performance JavaScript modules (Three.js 3D background animation, catalog data, custom rig builder, cart drawer, and theme switcher).
- assets/: Branded logos, 100+ hardware component photographs, pre-built rig previews, and icons.

## How to Run & Deploy:
1. Local Viewing:
   - Simply double-click index.html or products.html to open in any modern web browser (Chrome, Firefox, Edge, Safari).
   - No npm install, no build step, and no backend dependencies are required.
2. Web Hosting:
   - Upload the extracted contents directly to any web hosting service (cPanel / Apache / Nginx / Hostinger / GoDaddy, or Netlify, Vercel, GitHub Pages, Cloudflare Pages).
